import ContactsList from './list'
import ContactsCreate from './create'
import ContactsDetail from './detail'

export {
  ContactsList,
  ContactsCreate,
  ContactsDetail
}
