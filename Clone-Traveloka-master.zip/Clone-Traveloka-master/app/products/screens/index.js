import ProductsList from './list'
import ProductsCreate from './create'
import ProductsDetail from './detail'

export {
  ProductsList,
  ProductsCreate,
  ProductsDetail
}
