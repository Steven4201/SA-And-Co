import ProfilesList from './list'
import ProfilesCreate from './create'
import ProfilesDetail from './detail'

export {
  ProfilesList,
  ProfilesCreate,
  ProfilesDetail
}
