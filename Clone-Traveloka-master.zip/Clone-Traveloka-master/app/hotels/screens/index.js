import HotelsList from './list'
import HotelsCreate from './create'
import HotelsDetail from './detail'
import HotelsSearch from './search'
import LocationsSearch from './locations'

export {
  HotelsList,
  HotelsCreate,
  HotelsDetail,
  HotelsSearch,
  LocationsSearch
}
