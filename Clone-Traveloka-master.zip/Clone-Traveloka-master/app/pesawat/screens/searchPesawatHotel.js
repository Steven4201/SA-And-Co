import React, { Component } from 'react'
import { 
    Icon, Button , List, ListItem,
    Card, CardItem, Container, Text
} from 'native-base'

import { Grid, Col, Row } from 'react-native-easy-grid'
import { 
    View, 
} from 'react-native' 
 
export default class SearchPesawatHotel extends Component {
    render() {
        return (
            <View>
                <Text>asdfasf</Text>
            </View>
        )
    }
}
