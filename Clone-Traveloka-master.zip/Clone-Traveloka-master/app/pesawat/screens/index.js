import PesawatsList from './list'
import PesawatsCreate from './create'
import PesawatsDetail from './detail'
import topTab  from './topBar'

export {
  PesawatsList,
  PesawatsCreate,
  PesawatsDetail,
  topTab
  
}
