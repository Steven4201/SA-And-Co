import HomepagesList from './list'
import HomepagesCreate from './create'
import HomepagesDetail from './detail'
import Homepage from './homepage'

export {
  HomepagesList,
  HomepagesCreate,
  HomepagesDetail,
  Homepage,
  
  
}
